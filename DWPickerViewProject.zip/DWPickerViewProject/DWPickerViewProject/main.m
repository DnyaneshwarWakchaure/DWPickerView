//
//  main.m
//  DWPickerViewProject
//
//  Created by dnyaneshwar on 27/03/17.
//  Copyright © 2017 dnyaneshwar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
